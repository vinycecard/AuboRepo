#include "Example_IO.h"
#include "util.h"
#include <stdio.h>
#include <sstream>
#include <fstream>
#include <string.h>
#include <unistd.h>
#include <math.h>

#define SERVER_HOST "192.168.1.102"
#define SERVER_PORT 8899
void Example_IO::BoardIO(){
    ServiceInterface robotService;

    int ret = aubo_robot_namespace::InterfaceCallSuccCode;


    /** Interface call: Login ***/
    ret = robotService.robotServiceLogin(SERVER_HOST, SERVER_PORT, "aubo", "123456");
    if(ret == aubo_robot_namespace::InterfaceCallSuccCode)
    {
        std::cerr<<"Login successfully."<<std::endl;
    }
    else
    {
        std::cerr<<"Login unsuccessfully."<<std::endl;
    }
    //get all board AI status
    std::vector<aubo_robot_namespace::RobotIoType> ioType;
    std::vector<aubo_robot_namespace::RobotIoDesc> statusVector;

    ioType.push_back(aubo_robot_namespace::RobotBoardUserAI);
    robotService.robotServiceGetBoardIOStatus(ioType, statusVector);

    for(int i=0;i<statusVector.size();i++){
    std::cerr<<statusVector[i].ioName<<"   "<<statusVector[i].ioValue<<std::endl;
    }
    //get U_DI_01 status
    double value;

    robotService.robotServiceGetBoardIOStatus(aubo_robot_namespace::RobotBoardUserDI, "U_DI_01", value);

    std::cerr<<"DI_01 status:"<<value<<std::endl;

   //set U_DO_02 status
    robotService.robotServiceSetBoardIOStatus(aubo_robot_namespace::RobotBoardUserDO, "U_DO_02", 0);

}
void Example_IO::ToolIO(){
    ServiceInterface robotService;

    int ret = aubo_robot_namespace::InterfaceCallSuccCode;

    //Interface call: Login
    ret = robotService.robotServiceLogin(SERVER_HOST, SERVER_PORT, "aubo", "123456");
    if(ret == aubo_robot_namespace::InterfaceCallSuccCode)
    {
        std::cerr<<"Login successfully."<<std::endl;
    }
    else
    {
        std::cerr<<"Login unsuccessfully."<<std::endl;
    }
     double value;
     std::vector<aubo_robot_namespace::RobotIoDesc> statusVector;

     //get tool power type
    aubo_robot_namespace::ToolPowerType type;
   robotService.robotServiceGetToolPowerVoltageType(type);
    std::cerr<<"Tool Power type"<<type<<std::endl;


   //set tool power type
    type = aubo_robot_namespace::OUT_12V;
   robotService.robotServiceSetToolPowerVoltageType(type);


   //get tool power value
   robotService.robotServiceGetToolPowerVoltageStatus(value);
   std::cerr<<"Tool power value:"<<value<<std::endl;


   //get all tool digital I/O status
   robotService.robotServiceGetAllToolDigitalIOStatus(statusVector);
   for(int i=0;i<statusVector.size();i++){
   std::cerr<<statusVector[i].ioName<<"   "<<statusVector[i].ioValue<<std::endl;
   }

   //get I/O status by name
  robotService.robotServiceGetToolIoStatus("T_DI/O_00", value);
  std::cerr<<"T_DI/O_00:"<<value<<std::endl;

  //get all tool analog input status
   robotService.robotServiceGetAllToolAIStatus(statusVector);
   for(int i=0;i<statusVector.size();i++){
   std::cerr<<statusVector[i].ioName<<"   "<<statusVector[i].ioValue<<std::endl;
   }


}

