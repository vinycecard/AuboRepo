#ifndef EXAMPLE_INIT
#define EXAMPLE_INIT
#include "AuboRobotMetaType.h"
#include "serviceinterface.h"
class Example_init
{

public:
  static void initialization();


};
#endif // EXAMPLE_INIT

