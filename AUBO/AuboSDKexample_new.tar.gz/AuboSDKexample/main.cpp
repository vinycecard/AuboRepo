#include "Example_movement.h"
#include "Example_init.h"
#include "Example_getinfo.h"
#include "Example_algorithm.h"
#include "Example_IO.h"
#include <stdio.h>
#include <sstream>
#include <fstream>
#include <string.h>
#include <unistd.h>
#include <math.h>


int main(){
    //Example_init::initialization();

    //Example_getinfo::eventpush();
    //Example_getinfo::getJointStatus();
    //Example_getinfo::getToolPara();

    //Example_movement::JointMove();
    //Example_movement::LinearMove();
    //Example_movement::TrackMove();
    //Example_movement::RotaryMove();
    //Example_movement::ArriveAhead();

    //Example_algorithm::FK();
    //Example_algorithm::IK();
    //Example_algorithm::BaseToEnd();


    //Example_IO::BoardIO();
    Example_IO::ToolIO();


}
