#include "Example_movement.h"
#include "util.h"
#include <stdio.h>
#include <sstream>
#include <fstream>
#include <string.h>
#include <unistd.h>
#include <math.h>

#define SERVER_HOST "192.168.1.102"
#define SERVER_PORT 8899
/**
* Example_movement: joint movement
* step1: Login
* step2: Initialize the movement property
* step3: Set the maximum acceleration of joint movement
* step4: Set the maximum velocity of joint movement
* step5: Robot moves to zero position
* step6: Set the offset
* step7: Robot moves to 4 target points which described by joint angle in joint movement for 4 times,
*        each point will shift to z-axis after this loop
* step8: Robot moves to 3 target points which described by coordinates in joint movement for 3 times
* step9: Logout
*/
void Example_movement::JointMove(){
    ServiceInterface robotService;

    int ret = aubo_robot_namespace::InterfaceCallSuccCode;

    /** interface call: login ***/
    ret = robotService.robotServiceLogin(SERVER_HOST, SERVER_PORT, "aubo", "123456");
    if(ret == aubo_robot_namespace::InterfaceCallSuccCode)
    {
        std::cerr<<"login successfully."<<std::endl;
    }
    else
    {
        std::cerr<<"login unsuccessfully."<<std::endl;
    }


    /** Interface call: Initialize the movement property ***/
    robotService.robotServiceInitGlobalMoveProfile();
    /** Interface call: Set the maximum acceleration of joint movement ***/
    aubo_robot_namespace::JointVelcAccParam jointMaxAcc;
   // aubo_robot_namespace::JointVelcAccParam MaxAcc;
    jointMaxAcc.jointPara[0] = 50.0/180.0*M_PI;
    jointMaxAcc.jointPara[1] = 50.0/180.0*M_PI;
    jointMaxAcc.jointPara[2] = 50.0/180.0*M_PI;
    jointMaxAcc.jointPara[3] = 50.0/180.0*M_PI;
    jointMaxAcc.jointPara[4] = 50.0/180.0*M_PI;
    jointMaxAcc.jointPara[5] = 50.0/180.0*M_PI;   //The interface requires that the unit is radian
    robotService.robotServiceSetGlobalMoveJointMaxAcc(jointMaxAcc);
    /** Interface call: Set the maximum velocity of the joint movement ***/
    aubo_robot_namespace::JointVelcAccParam jointMaxVelc;
    jointMaxVelc.jointPara[0] = 50.0/180.0*M_PI;
    jointMaxVelc.jointPara[1] = 50.0/180.0*M_PI;
    jointMaxVelc.jointPara[2] = 50.0/180.0*M_PI;
    jointMaxVelc.jointPara[3] = 50.0/180.0*M_PI;
    jointMaxVelc.jointPara[4] = 50.0/180.0*M_PI;
    jointMaxVelc.jointPara[5] = 50.0/180.0*M_PI;   //The interface requires that the unit is radian
    robotService.robotServiceSetGlobalMoveJointMaxVelc(jointMaxVelc);

    /** Moving robot to zero position **/
    double jointAngle[aubo_robot_namespace::ARM_DOF] = {0};
    jointAngle[0] = 0.0/180.0*M_PI;
    jointAngle[1] = 0.0/180.0*M_PI;
    jointAngle[2] = 0.0/180.0*M_PI;
    jointAngle[3] = 0.0/180.0*M_PI;
    jointAngle[4] = 0.0/180.0*M_PI;
    jointAngle[5] = 0.0/180.0*M_PI;
    ret = robotService.robotServiceJointMove(jointAngle, true);
    if(ret != aubo_robot_namespace::InterfaceCallSuccCode)
    {
        std::cerr<<"Moving 0 failed.　ret:"<<ret<<std::endl;
    }
    for(int i=0;i<4;i++)
    {
        /** Interface call: Set the offset**/
        aubo_robot_namespace::MoveRelative relativeMoveOnBase;
        relativeMoveOnBase.ena = true;
        relativeMoveOnBase.relativePosition[0] = 0;
        relativeMoveOnBase.relativePosition[1] = 0;
        relativeMoveOnBase.relativePosition[2] = 0.03*(i%3);   //Unit: meter
        relativeMoveOnBase.relativeOri.w=1;
        relativeMoveOnBase.relativeOri.x=0;
        relativeMoveOnBase.relativeOri.y=0;
        relativeMoveOnBase.relativeOri.z=0;
        robotService.robotServiceSetMoveRelativeParam(relativeMoveOnBase);

        jointAngle[0] = 0.0/180.0*M_PI;
        jointAngle[1] = 0.0/180.0*M_PI;
        jointAngle[2] = 90.0/180.0*M_PI;
        jointAngle[3] = 0.0/180.0*M_PI;
        jointAngle[4] = 90.0/180.0*M_PI;
        jointAngle[5] = 0.0/180.0*M_PI;
        robotService.robotServiceJointMove(jointAngle, true);
        if(ret != aubo_robot_namespace::InterfaceCallSuccCode)
        {
            std::cerr<<"Movement 1 failed.　ret:"<<ret<<std::endl;
            break;
        }

        jointAngle[0] = 15.0/180.0*M_PI;
        jointAngle[1] = 0.0/180.0*M_PI;
        jointAngle[2] = 90.0/180.0*M_PI;
        jointAngle[3] = 0.0/180.0*M_PI;
        jointAngle[4] = 90.0/180.0*M_PI;
        jointAngle[5] = 0.0/180.0*M_PI;
        robotService.robotServiceJointMove(jointAngle, true);
        if(ret != aubo_robot_namespace::InterfaceCallSuccCode)
        {
            std::cerr<<"Movement 2 failed.　ret:"<<ret<<std::endl;
             break;
        }

        jointAngle[0] = 30.0/180.0*M_PI;
        jointAngle[1] = 15.0/180.0*M_PI;
        jointAngle[2] = 90.0/180.0*M_PI;
        jointAngle[3] = 15.0/180.0*M_PI;
        jointAngle[4] = 90.0/180.0*M_PI;
        jointAngle[5] = 15.0/180.0*M_PI;
        robotService.robotServiceJointMove(jointAngle, true);
        if(ret != aubo_robot_namespace::InterfaceCallSuccCode)
        {
            std::cerr<<"Movement 3 failed.　ret:"<<ret<<std::endl;
             break;
        }

        jointAngle[0] = 60.0/180.0*M_PI;
        jointAngle[1] = 30.0/180.0*M_PI;
        jointAngle[2] = 90.0/180.0*M_PI;
        jointAngle[3] = 30.0/180.0*M_PI;
        jointAngle[4] = 90.0/180.0*M_PI;
        jointAngle[5] = 30.0/180.0*M_PI;
        robotService.robotServiceJointMove(jointAngle, true);
        if(ret != aubo_robot_namespace::InterfaceCallSuccCode)
        {
            std::cerr<<"Movement 4 failed.　ret:"<<ret<<std::endl;
             break;
        }

    }
    /** Robot moves to the ready position **/
    jointAngle[0] = 0.0/180.0*M_PI;
    jointAngle[1] = 0.0/180.0*M_PI;
    jointAngle[2] = 90.0/180.0*M_PI;
    jointAngle[3] = 0.0/180.0*M_PI;
    jointAngle[4] = 90.0/180.0*M_PI;
    jointAngle[5] = 0.0/180.0*M_PI;
    ret = robotService.robotServiceJointMove(jointAngle, true);   //Joint moves to the ready point
    if(ret != aubo_robot_namespace::InterfaceCallSuccCode)
    {
        std::cerr<<"Movement 0 failed.　ret:"<<ret<<std::endl;
    }

    aubo_robot_namespace::wayPoint_S currentWaypoint;
    ret = robotService.robotServiceGetCurrentWaypointInfo(currentWaypoint);
    if(ret != aubo_robot_namespace::InterfaceCallSuccCode)
    {
        std::cerr<<"Fail to get the current waypoint information.　ret:"<<ret<<std::endl;
    }
    /** Set the coordinate parameters **/
    aubo_robot_namespace::CoordCalibrateByJointAngleAndTool userCoord;
    userCoord.coordType = aubo_robot_namespace::BaseCoordinate;
    /** Set the tool parameters **/
    aubo_robot_namespace::ToolInEndDesc toolDesc;
    toolDesc.toolInEndPosition.x = 0;
    toolDesc.toolInEndPosition.y = 0;
    toolDesc.toolInEndPosition.z = 0;

    for(int i=0;i<9;i++)
    {

        aubo_robot_namespace::Pos position;
        double offsetY = (i%3 > 1)? 0.0:(0.18*(i%3));
        double offsetZ = (i%3 > 1)? 0.0:(0.18);
        position.x = currentWaypoint.cartPos.position.x;
        position.y = currentWaypoint.cartPos.position.y+offsetY;
        position.z = currentWaypoint.cartPos.position.z+offsetZ;

        //Keep the current posture, move to the target position in joint movement
        ret = robotService.robotMoveJointToTargetPosition(userCoord, position, toolDesc, true);
        if(ret != aubo_robot_namespace::InterfaceCallSuccCode)
        {
            std::cerr<<"robotMoveLineToTargetPosition.　ret:"<<ret<<std::endl;
        }

    }

    /** Interface call: logout　**/
    robotService.robotServiceLogout();

}
/**
 *Example_movement: linear movement
 *step1：login
 *step2：Move to initial position
 *step3：Initialize the movement property
 *step4：Set the maximum acceleration of the linear movement
 *step5：Set the maximum velocity of the linear movement
 *step6：Robot moves to 4 target points which described by joint angle in linear movement for 4 times
 *step7：Robot moves to 3 target points which described by coordinates in linear movement for 3 times
 *step8：Logout
 *
*/

void Example_movement::LinearMove()
{
    ServiceInterface robotService;

    int ret = aubo_robot_namespace::InterfaceCallSuccCode;

    /** Interface call: Login ***/
    ret = robotService.robotServiceLogin(SERVER_HOST, SERVER_PORT, "aubo", "123456");
    if(ret == aubo_robot_namespace::InterfaceCallSuccCode)
    {
        std::cerr<<"Login successfully."<<std::endl;
    }
    else
    {
        std::cerr<<"Login unsuccessfully."<<std::endl;
    }

    /** Moving to the initial position and posture **/
    double jointAngle[aubo_robot_namespace::ARM_DOF] = {0};
    jointAngle[0] = 0.0/180.0*M_PI;
    jointAngle[1] = 0.0/180.0*M_PI;
    jointAngle[2] = 90.0/180.0*M_PI;
    jointAngle[3] = 0.0/180.0*M_PI;
    jointAngle[4] = 90.0/180.0*M_PI;
    jointAngle[5] = 0.0/180.0*M_PI;
    ret = robotService.robotServiceJointMove(jointAngle, true);   //Joints move to ready position
    if(ret != aubo_robot_namespace::InterfaceCallSuccCode)
    {
        std::cerr<<"Movement 0 failed.　ret:"<<ret<<std::endl;
    }


    /** Interface call: Initialize movement property ***/
    robotService.robotServiceInitGlobalMoveProfile();

    /** Interface call: Set the maximum acceleration of end type movement 　　linear movement is belong to end type movement ***/
    double lineMoveMaxAcc;
    lineMoveMaxAcc = 4;   //unit: m/s
    robotService.robotServiceSetGlobalMoveEndMaxLineAcc(lineMoveMaxAcc);
    robotService.robotServiceSetGlobalMoveEndMaxAngleAcc(lineMoveMaxAcc);

    /** Interface call: Set the maximum velocity of the end type movement   linear movement is belong to end type movement ***/
    double lineMoveMaxVelc;
    lineMoveMaxVelc = 4;   //Unit: m/s
    robotService.robotServiceSetGlobalMoveEndMaxLineVelc(lineMoveMaxVelc);
    robotService.robotServiceGetGlobalMoveEndMaxAngleVelc(lineMoveMaxVelc);

    for(int i=0;i<4;i++)
    {
        double jointAngle[aubo_robot_namespace::ARM_DOF] = {0};
        jointAngle[0] = 0.0/180.0*M_PI;
        jointAngle[1] = 0.0/180.0*M_PI;
        jointAngle[2] = 90.0/180.0*M_PI;
        jointAngle[3] = 0.0/180.0*M_PI;
        jointAngle[4] = 90.0/180.0*M_PI;
        jointAngle[5] = 0.0/180.0*M_PI;
        ret = robotService.robotServiceLineMove(jointAngle, true);
        if(ret != aubo_robot_namespace::InterfaceCallSuccCode)
        {
            std::cerr<<"Movement 0 failed.　ret:"<<ret<<std::endl;
        }

        jointAngle[0] = 0.0/180.0*M_PI;
        jointAngle[1] = 0.0/180.0*M_PI;
        jointAngle[2] = 45.0/180.0*M_PI;
        jointAngle[3] = 0.0/180.0*M_PI;
        jointAngle[4] = 90.0/180.0*M_PI;
        jointAngle[5] = 0.0/180.0*M_PI;
        robotService.robotServiceLineMove(jointAngle, true);
        if(ret != aubo_robot_namespace::InterfaceCallSuccCode)
        {
            std::cerr<<"Movement 1 failed.　ret:"<<ret<<std::endl;
        }

        jointAngle[0] = 30.0/180.0*M_PI;
        jointAngle[1] = 0.0/180.0*M_PI;
        jointAngle[2] = 45.0/180.0*M_PI;
        jointAngle[3] = 0.0/180.0*M_PI;
        jointAngle[4] = 90.0/180.0*M_PI;
        jointAngle[5] = 0.0/180.0*M_PI;
        robotService.robotServiceLineMove(jointAngle, true);
        if(ret != aubo_robot_namespace::InterfaceCallSuccCode)
        {
            std::cerr<<"Movement 2 failed.　ret:"<<ret<<std::endl;
        }

        jointAngle[0] = 30.0/180.0*M_PI;
        jointAngle[1] = 0.0/180.0*M_PI;
        jointAngle[2] = 90.0/180.0*M_PI;
        jointAngle[3] = 0.0/180.0*M_PI;
        jointAngle[4] = 90.0/180.0*M_PI;
        jointAngle[5] = 0.0/180.0*M_PI;
        robotService.robotServiceLineMove(jointAngle, true);
        if(ret != aubo_robot_namespace::InterfaceCallSuccCode)
        {
            std::cerr<<"Movement 3 failed.　ret:"<<ret<<std::endl;
        }
    }
    /** Robot moves to the ready position **/
    jointAngle[0] = 0.0/180.0*M_PI;
    jointAngle[1] = 0.0/180.0*M_PI;
    jointAngle[2] = 90.0/180.0*M_PI;
    jointAngle[3] = 0.0/180.0*M_PI;
    jointAngle[4] = 90.0/180.0*M_PI;
    jointAngle[5] = 0.0/180.0*M_PI;
    ret = robotService.robotServiceLineMove(jointAngle, true);   //Joint moves to the ready point

    aubo_robot_namespace::wayPoint_S currentWaypoint;
    ret = robotService.robotServiceGetCurrentWaypointInfo(currentWaypoint);
    if(ret != aubo_robot_namespace::InterfaceCallSuccCode)
    {
        std::cerr<<"Fail to get the current waypoint information.　ret:"<<ret<<std::endl;
    }
    /** Set the coordinate parameters **/
    aubo_robot_namespace::CoordCalibrateByJointAngleAndTool userCoord;
    userCoord.coordType = aubo_robot_namespace::BaseCoordinate;
    /** Set the tool parameters **/
    aubo_robot_namespace::ToolInEndDesc toolDesc;
    toolDesc.toolInEndPosition.x = 0;
    toolDesc.toolInEndPosition.y = 0;
    toolDesc.toolInEndPosition.z = 0;

    for(int i=0;i<9;i++)
    {

        aubo_robot_namespace::Pos position;
        double offsetY = (i%3 > 1)? 0.0:(0.18*(i%3));
        double offsetZ = (i%3 > 1)? 0.0:(0.18);
        position.x = currentWaypoint.cartPos.position.x;
        position.y = currentWaypoint.cartPos.position.y+offsetY;
        position.z = currentWaypoint.cartPos.position.z+offsetZ;


        ret = robotService.robotMoveLineToTargetPosition(userCoord, position, toolDesc, true);
        if(ret != aubo_robot_namespace::InterfaceCallSuccCode)
        {
            std::cerr<<"robotMoveLineToTargetPosition.　ret:"<<ret<<std::endl;
        }

    }


    /** Interface call: Logout　**/
    robotService.robotServiceLogout();
}

/**
 *Example_movement: track movement
 *step1：login
 *step2：Move to initial position and posture
 *step3：Initialize the joint movement property
 *step4：Initialize the end type movement property
 *step5：Arc
 *step6：Circle
 *step7：movep
 *step8：Logout
 *
 */
void Example_movement::TrackMove()
{
    ServiceInterface robotService;

    int ret = aubo_robot_namespace::InterfaceCallSuccCode;

    /** Interface call: Login ***/
    ret = robotService.robotServiceLogin(SERVER_HOST, SERVER_PORT, "aubo", "123456");
    if(ret == aubo_robot_namespace::InterfaceCallSuccCode)
    {
        std::cerr<<"Login successfully."<<std::endl;
    }
    else
    {
        std::cerr<<"Login unsuccessfully."<<std::endl;
    }


    /** Interface call: Initialize  the movement property ***/
    robotService.robotServiceInitGlobalMoveProfile();

    /** Interface call: Set the maximum acceleration of joint movement ***/
    aubo_robot_namespace::JointVelcAccParam jointMaxAcc;
    jointMaxAcc.jointPara[0] = 50.0/180.0*M_PI;
    jointMaxAcc.jointPara[1] = 50.0/180.0*M_PI;
    jointMaxAcc.jointPara[2] = 50.0/180.0*M_PI;
    jointMaxAcc.jointPara[3] = 50.0/180.0*M_PI;
    jointMaxAcc.jointPara[4] = 50.0/180.0*M_PI;
    jointMaxAcc.jointPara[5] = 50.0/180.0*M_PI;   //The interface requires that the unit is radian
    robotService.robotServiceSetGlobalMoveJointMaxAcc(jointMaxAcc);

    /** Interface call: Set the maximum velocity of the joint movement ***/
    aubo_robot_namespace::JointVelcAccParam jointMaxVelc;
    jointMaxVelc.jointPara[0] = 50.0/180.0*M_PI;
    jointMaxVelc.jointPara[1] = 50.0/180.0*M_PI;
    jointMaxVelc.jointPara[2] = 50.0/180.0*M_PI;
    jointMaxVelc.jointPara[3] = 50.0/180.0*M_PI;
    jointMaxVelc.jointPara[4] = 50.0/180.0*M_PI;
    jointMaxVelc.jointPara[5] = 50.0/180.0*M_PI;   //The interface requires that the unit is radian
    robotService.robotServiceSetGlobalMoveJointMaxVelc(jointMaxVelc);

    /** Interface call: Initialize the movement property ***/
    robotService.robotServiceInitGlobalMoveProfile();

    /** Interface call: Set the maximum acceleration of the end type movement 　　linear movement is belong to end type movement***/
    double endMoveMaxAcc;
    endMoveMaxAcc = 0.2;   //Unit: m/s
    robotService.robotServiceSetGlobalMoveEndMaxLineAcc(endMoveMaxAcc);
    robotService.robotServiceSetGlobalMoveEndMaxAngleAcc(endMoveMaxAcc);


    /** Interface call: Set the maximum velocity of the end type movement linear movement is belong to end type movement***/
    double endMoveMaxVelc;
    endMoveMaxVelc = 0.2;   //Unit: m/s
    robotService.robotServiceSetGlobalMoveEndMaxLineVelc(endMoveMaxVelc);
    robotService.robotServiceSetGlobalMoveEndMaxAngleVelc(endMoveMaxVelc);

    double jointAngle[aubo_robot_namespace::ARM_DOF];

        //ready point  Joint movement is belong to joint type movement


        Util::initJointAngleArray(jointAngle,-0.000003, -0.127267, -1.321122, 0.376934, -1.570796, -0.000008);
        ret = robotService.robotServiceJointMove(jointAngle, true);   //Joint moves to the ready point
        if(ret != aubo_robot_namespace::InterfaceCallSuccCode)
        {
            std::cerr<<"JointMove failed.　ret:"<<ret<<std::endl;
        }


        //Arc
        robotService.robotServiceClearGlobalWayPointVector();
        Util::initJointAngleArray(jointAngle,-0.000003, -0.127267, -1.321122, 0.376934, -1.570796, -0.000008);
        robotService.robotServiceAddGlobalWayPoint(jointAngle);
        Util::initJointAngleArray(jointAngle,-0.211675, -0.325189, -1.466753, 0.429232, -1.570794, -0.211680);
        robotService.robotServiceAddGlobalWayPoint(jointAngle);
        Util::initJointAngleArray(jointAngle,-0.537186, -0.224307, -1.398285, 0.396819, -1.570796, -0.037191);
        robotService.robotServiceAddGlobalWayPoint(jointAngle);

        robotService.robotServiceSetGlobalCircularLoopTimes(0);    //Cycles of the circle
        ret = robotService.robotServiceTrackMove(aubo_robot_namespace::ARC_CIR, true);

        if(ret != aubo_robot_namespace::InterfaceCallSuccCode)
        {
            std::cerr<<"TrackMove failed.　ret:"<<ret<<std::endl;
        }


       //ready point
        Util::initJointAngleArray(jointAngle,-0.000003, -0.127267, -1.321122, 0.376934, -1.570796, -0.000008);
        ret = robotService.robotServiceJointMove(jointAngle, true);   //Joint moves to the ready point
        if(ret != aubo_robot_namespace::InterfaceCallSuccCode)
        {
            std::cerr<<"JointMove failed.　ret:"<<ret<<std::endl;
        }

        //Circle
        robotService.robotServiceClearGlobalWayPointVector();
        Util::initJointAngleArray(jointAngle,-0.000003, -0.127267, -1.321122, 0.376934, -1.570796, -0.000008);
        robotService.robotServiceAddGlobalWayPoint(jointAngle);
        Util::initJointAngleArray(jointAngle,-0.211675, -0.325189, -1.466753, 0.429232, -1.570794, -0.211680);
        robotService.robotServiceAddGlobalWayPoint(jointAngle);
        Util::initJointAngleArray(jointAngle,-0.537186, -0.224307, -1.398285, 0.396819, -1.570796, -0.037191);
        robotService.robotServiceAddGlobalWayPoint(jointAngle);

        robotService.robotServiceSetGlobalCircularLoopTimes(1);    //Cycles of the circle
        ret = robotService.robotServiceTrackMove(aubo_robot_namespace::ARC_CIR,true);
        if(ret != aubo_robot_namespace::InterfaceCallSuccCode)
        {
            std::cerr<<"TrackMove failed.　ret:"<<ret<<std::endl;
        }


        //Ready point
        Util::initJointAngleArray(jointAngle,-0.000003, -0.127267, -1.321122, 0.376934, -1.570796, -0.000008);
        ret = robotService.robotServiceJointMove(jointAngle, true);   //Joint moves to the ready point
        if(ret != aubo_robot_namespace::InterfaceCallSuccCode)
        {
            std::cerr<<"JointMove failed.　ret:"<<ret<<std::endl;
        }

        //MoveP

        robotService.robotServiceClearGlobalWayPointVector();
        Util::initJointAngleArray(jointAngle,-0.000003, -0.127267, -1.321122, 0.376934, -1.570796, -0.000008);
        robotService.robotServiceAddGlobalWayPoint(jointAngle);
        Util::initJointAngleArray(jointAngle,0.600000, -0.147267, -1.321122, 0.376934, -1.570794, -0.000008);
        robotService.robotServiceAddGlobalWayPoint(jointAngle);
        Util::initJointAngleArray(jointAngle,1.000000, -0.167267, -1.321122, 0.376934, -1.570796, -0.000008);
        robotService.robotServiceAddGlobalWayPoint(jointAngle);

        robotService.robotServiceSetGlobalBlendRadius(0.03);                     //Blend radius
        ret = robotService.robotServiceTrackMove(aubo_robot_namespace::CARTESIAN_MOVEP,true);
        if(ret != aubo_robot_namespace::InterfaceCallSuccCode)
        {
            std::cerr<<"TrackMove failed.　ret:"<<ret<<std::endl;
        }
    /** Interface call: Logout　**/
    robotService.robotServiceLogout();
}

/**
 *Example_movement: rotary movement
 *step1：login
 *step2：Move to initial position
 *step3：Initialize the movement property
 *step4：Set the maximum acceleration of the joint movement
 *step5：Set the maximum velocity of the joint movement
 *step6：Robot keeps the current position and rotates along y axis by -45 degree
 *step8：Logout
 *
*/
void Example_movement::RotaryMove()
{
    ServiceInterface robotService;

    int ret = aubo_robot_namespace::InterfaceCallSuccCode;

    /** Interface call: Login ***/
    ret = robotService.robotServiceLogin(SERVER_HOST, SERVER_PORT, "aubo", "123456");
    if(ret == aubo_robot_namespace::InterfaceCallSuccCode)
    {
        std::cerr<<"Login successfully."<<std::endl;
    }
    else
    {
        std::cerr<<"Login unsuccessfully."<<std::endl;
    }


    /** Interface call: Initialize  the movement property ***/
    robotService.robotServiceInitGlobalMoveProfile();

    /** Interface call: Set the maximum acceleration of joint movement ***/
    aubo_robot_namespace::JointVelcAccParam jointMaxAcc;
    jointMaxAcc.jointPara[0] = 50.0/180.0*M_PI;
    jointMaxAcc.jointPara[1] = 50.0/180.0*M_PI;
    jointMaxAcc.jointPara[2] = 50.0/180.0*M_PI;
    jointMaxAcc.jointPara[3] = 50.0/180.0*M_PI;
    jointMaxAcc.jointPara[4] = 50.0/180.0*M_PI;
    jointMaxAcc.jointPara[5] = 50.0/180.0*M_PI;   //The interface requires that the unit is radian
    robotService.robotServiceSetGlobalMoveJointMaxAcc(jointMaxAcc);

    /** Interface call: Set the maximum velocity of the joint movement ***/
    aubo_robot_namespace::JointVelcAccParam jointMaxVelc;
    jointMaxVelc.jointPara[0] = 50.0/180.0*M_PI;
    jointMaxVelc.jointPara[1] = 50.0/180.0*M_PI;
    jointMaxVelc.jointPara[2] = 50.0/180.0*M_PI;
    jointMaxVelc.jointPara[3] = 50.0/180.0*M_PI;
    jointMaxVelc.jointPara[4] = 50.0/180.0*M_PI;
    jointMaxVelc.jointPara[5] = 50.0/180.0*M_PI;   //The interface requires that the unit is radian
    robotService.robotServiceSetGlobalMoveJointMaxVelc(jointMaxVelc);

    /** Robot moves to the ready position **/
    double jointAngle[aubo_robot_namespace::ARM_DOF] = {0};
    jointAngle[0] = 0.0/180.0*M_PI;
    jointAngle[1] = 0.0/180.0*M_PI;
    jointAngle[2] = 90.0/180.0*M_PI;
    jointAngle[3] = 0.0/180.0*M_PI;
    jointAngle[4] = 90.0/180.0*M_PI;
    jointAngle[5] = 0.0/180.0*M_PI;
    ret = robotService.robotServiceJointMove(jointAngle, true);   //Joint moves to the ready point
    if(ret != aubo_robot_namespace::InterfaceCallSuccCode)
    {
        std::cerr<<"Movement 0 failed.　ret:"<<ret<<std::endl;
    }

    aubo_robot_namespace::wayPoint_S currentWaypoint;
    ret = robotService.robotServiceGetCurrentWaypointInfo(currentWaypoint);
    if(ret != aubo_robot_namespace::InterfaceCallSuccCode)
    {
        std::cerr<<"Fail to get the current waypoint information.　ret:"<<ret<<std::endl;
    }
    /** Set the coordinate parameters **/
    aubo_robot_namespace::CoordCalibrateByJointAngleAndTool userCoord;
    userCoord.coordType = aubo_robot_namespace::BaseCoordinate;


   /** Along y axis rotate -45 degree **/
    double rotateAxis[3] = {0 ,1 ,0};
    ret = robotService.robotServiceRotateMove(userCoord, rotateAxis, -45.0/180.0*M_PI, true);
    if(ret != aubo_robot_namespace::InterfaceCallSuccCode)
    {
       std::cerr<<"robotServiceRotateMove　ret:"<<ret<<std::endl;
    }



    /** Interface call: Logout　**/
    robotService.robotServiceLogout();
}

/**
  *Example_movement: ArriveAhead()
  *setp1：Login
  *setp2：Initialize the maximum acceleration and velocity
  *setp3: move to target position by using SetArrivalAheadDistanceMode
  *step4: move to same target position without SetArrivalAheadDistanceMode
  *step5：Logout
  */
void Example_movement::ArriveAhead()
{

    ServiceInterface robotService;

    int ret = aubo_robot_namespace::InterfaceCallSuccCode;

    /** Interface call: Login ***/
    ret = robotService.robotServiceLogin(SERVER_HOST, SERVER_PORT, "aubo", "123456");
    if(ret == aubo_robot_namespace::InterfaceCallSuccCode)
    {
        std::cerr<<"Login successfully."<<std::endl;
    }
    else
    {
        std::cerr<<"Login unsuccessfully."<<std::endl;
    }



    /** Interface call: Initialize the movement property ***/
    robotService.robotServiceInitGlobalMoveProfile();

    /** Interface call: Set the maximum acceleration of joint movement ***/
    aubo_robot_namespace::JointVelcAccParam jointMaxAcc;
    jointMaxAcc.jointPara[0] = 50.0/180.0*M_PI;
    jointMaxAcc.jointPara[1] = 50.0/180.0*M_PI;
    jointMaxAcc.jointPara[2] = 50.0/180.0*M_PI;
    jointMaxAcc.jointPara[3] = 50.0/180.0*M_PI;
    jointMaxAcc.jointPara[4] = 50.0/180.0*M_PI;
    jointMaxAcc.jointPara[5] = 50.0/180.0*M_PI;   //The interface requires that the unit is radian
    robotService.robotServiceSetGlobalMoveJointMaxAcc(jointMaxAcc);

    /** Interface call: Set the maximum velocity of the joint movement ***/
    aubo_robot_namespace::JointVelcAccParam jointMaxVelc;
    jointMaxVelc.jointPara[0] = 50.0/180.0*M_PI;
    jointMaxVelc.jointPara[1] = 50.0/180.0*M_PI;
    jointMaxVelc.jointPara[2] = 50.0/180.0*M_PI;
    jointMaxVelc.jointPara[3] = 50.0/180.0*M_PI;
    jointMaxVelc.jointPara[4] = 50.0/180.0*M_PI;
    jointMaxVelc.jointPara[5] = 50.0/180.0*M_PI;   //The interface requires that the unit is radian
    robotService.robotServiceSetGlobalMoveJointMaxVelc(jointMaxVelc);

    /** Moving robot to zero position **/
    double jointAngle[aubo_robot_namespace::ARM_DOF] = {0};
    jointAngle[0] = 0.0/180.0*M_PI;
    jointAngle[1] = 0.0/180.0*M_PI;
    jointAngle[2] = 0.0/180.0*M_PI;
    jointAngle[3] = 0.0/180.0*M_PI;
    jointAngle[4] = 0.0/180.0*M_PI;
    jointAngle[5] = 0.0/180.0*M_PI;
    ret = robotService.robotServiceJointMove(jointAngle, true);
    if(ret != aubo_robot_namespace::InterfaceCallSuccCode)
    {
        std::cerr<<"Movement 0 failed.　ret:"<<ret<<std::endl;
    }

    for(int i=0;i<5;i++)

    {
          if(i%2==0)
        {
            /** The following mode of the get in position in advance, joint movement only **/
            robotService.robotServiceSetArrivalAheadDistanceMode(0.2);
            std::cerr<<"SetAheadDistanceMode is on"<<std::endl;
        }
        else
        {
            robotService.robotServiceSetNoArrivalAhead();
            std::cerr<<"SetAheadDistanceMode is off"<<std::endl;
        }

        jointAngle[0] = 0.0/180.0*M_PI;
        jointAngle[1] = 0.0/180.0*M_PI;
        jointAngle[2] = 0.0/180.0*M_PI;
        jointAngle[3] = 0.0/180.0*M_PI;
        jointAngle[4] = 0.0/180.0*M_PI;
        jointAngle[5] = 0.0/180.0*M_PI;
        ret = robotService.robotServiceJointMove(jointAngle, true);
        if(ret != aubo_robot_namespace::InterfaceCallSuccCode)
        {
            std::cerr<<"Movement  unsuccessful.　ret:"<<ret<<std::endl;
            break;
        }


        jointAngle[0] = 0.0/180.0*M_PI;
        jointAngle[1] = 0.0/180.0*M_PI;
        jointAngle[2] = 90.0/180.0*M_PI;
        jointAngle[3] = 0.0/180.0*M_PI;
        jointAngle[4] = 90.0/180.0*M_PI;
        jointAngle[5] = 0.0/180.0*M_PI;
        robotService.robotServiceJointMove(jointAngle, true);
        if(ret != aubo_robot_namespace::InterfaceCallSuccCode)
        {
            std::cerr<<"Movement  unsuccessful.　ret:"<<ret<<std::endl;
            break;
        }


        jointAngle[0] = 90.0/180.0*M_PI;
        jointAngle[1] = 0.0/180.0*M_PI;
        jointAngle[2] = 90.0/180.0*M_PI;
        jointAngle[3] = 0.0/180.0*M_PI;
        jointAngle[4] = 90.0/180.0*M_PI;
        jointAngle[5] = 0.0/180.0*M_PI;
        robotService.robotServiceJointMove(jointAngle, true);
        if(ret != aubo_robot_namespace::InterfaceCallSuccCode)
        {
            std::cerr<<"Movement  unsuccessful.　ret:"<<ret<<std::endl;
             break;
        }

    }

    std::cout<<"------------------"<<std::endl;
}
