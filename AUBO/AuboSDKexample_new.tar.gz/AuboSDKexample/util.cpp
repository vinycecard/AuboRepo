#include "util.h"

#include <unistd.h>
#include <math.h>
#include <string.h>
#include <stdio.h>
#include <sstream>
#include <fstream>

Util::Util()
{
}

//print waypoint information
void Util::printWaypoint(aubo_robot_namespace::wayPoint_S &wayPoint)
{
    ServiceInterface robotService;

    std::cout<<std::endl<<"start-------------waypoint information---------------"<<std::endl;
    //position
    std::cout<<"position infromation: ";
    std::cout<<"x:"<<wayPoint.cartPos.position.x<<"  ";
    std::cout<<"y:"<<wayPoint.cartPos.position.y<<"  ";
    std::cout<<"z:"<<wayPoint.cartPos.position.z<<std::endl;
    //quaternion
    std::cout<<"posture infromation described by quaternion: ";
    std::cout<<"w:"<<wayPoint.orientation.w<<"  ";
    std::cout<<"x:"<<wayPoint.orientation.x<<"  ";
    std::cout<<"y:"<<wayPoint.orientation.y<<"  ";
    std::cout<<"z:"<<wayPoint.orientation.z<<std::endl;
    //Euler angles
    aubo_robot_namespace::Rpy tempRpy;
    robotService.quaternionToRPY(wayPoint.orientation,tempRpy);
    std::cout<<"posture infromation described by Euler angles: ";
    std::cout<<"RX:"<<tempRpy.rx<<"  RY:"<<tempRpy.ry<<"   RZ:"<<tempRpy.rz<<std::endl;
    //angle of each joint
    std::cout<<"joint angle: "<<std::endl;
    for(int i=0;i<aubo_robot_namespace::ARM_DOF;i++)
    {
        std::cout<<i+1<<"."<<"joint(radian)"<<": "<<wayPoint.jointpos[i]<<" | "<<"joint(degree)"<<wayPoint.jointpos[i]*180.0/M_PI<<std::endl;
    }


    std::cout<<std::endl<<"----------------------------------end."<<std::endl;
}


//print joint status information
void Util::printJointStatus(const aubo_robot_namespace::JointStatus *jointStatus, int len)
{
    std::cout<<std::endl<<"start----------joint status information-------" << std::endl;

    for(int i=0; i<len; i++)
    {
        std::cout<<"Joint ID:"   <<i<<"  " ;
        std::cout<<"Current:"     <<jointStatus[i].jointCurrentI<<" ";
        std::cout<<"Speed:"     <<jointStatus[i].jointSpeedMoto<<" ";
        std::cout<<"Joint Angle:"   <<jointStatus[i].jointPosJ<<" ";
        std::cout<<"Voltage   :"  <<jointStatus[i].jointCurVol<<" ";
        std::cout<<"Temperature   :"  <<jointStatus[i].jointCurTemp<<" ";
        std::cout<<"Target current:"  <<jointStatus[i].jointTagCurrentI<<" ";
        std::cout<<"Target motor speed:" <<jointStatus[i].jointTagSpeedMoto<<" ";
        std::cout<<"Target joint angle :"  <<jointStatus[i].jointTagPosJ<<" ";
        std::cout<<"Joint error   :"  <<jointStatus[i].jointErrorNum <<std::endl;
    }
    std::cout<<std::endl;
}


//Print event information
void Util::printEventInfo(const aubo_robot_namespace::RobotEventInfo &eventInfo)
{
    std::cout<<"event type:"<<eventInfo.eventType <<"  code:"<<eventInfo.eventCode<<"  content:"<<eventInfo.eventContent<<std::endl;
}


void Util::printRobotDiagnosis(const aubo_robot_namespace::RobotDiagnosis &robotDiagnosis)
{
    std::cout<<std::endl<<"start----------Robot information statistic-------" << std::endl;

    std::cout<<std::endl<<"   "<<"CAN communication status:"<<(int)robotDiagnosis.armCanbusStatus;
    std::cout<<std::endl<<"   "<<"The current power current:"<<robotDiagnosis.armPowerCurrent;
    std::cout<<std::endl<<"   "<<"The current power voltage:"<<robotDiagnosis.armPowerVoltage;

    (robotDiagnosis.armPowerStatus)? std::cout<<std::endl<<"   "<<"48V power status: on":std::cout<<std::endl<<"   "<<"48V power status: off";

    std::cout<<std::endl<<"   "<<"Temperature of control box:"<<(int)robotDiagnosis.contorllerTemp;
    std::cout<<std::endl<<"   "<<"Moisture of control box:"<<(int)robotDiagnosis.contorllerHumidity;
    std::cout<<std::endl<<"   "<<"Remote halt signal:"<<robotDiagnosis.remoteHalt;
    std::cout<<std::endl<<"   "<<"Robot soft emergency stop button:"<<robotDiagnosis.softEmergency;
    std::cout<<std::endl<<"   "<<"Remote emergency stop signal:"<<robotDiagnosis.remoteEmergency;
    std::cout<<std::endl<<"   "<<"Collision detection bit:"<<robotDiagnosis.robotCollision;
    std::cout<<std::endl<<"   "<<"The flag of starting force control mode:"<<robotDiagnosis.forceControlMode;
    std::cout<<std::endl<<"   "<<"Brake status:"<<robotDiagnosis.brakeStuats;
    std::cout<<std::endl<<"   "<<"End speed:"<<robotDiagnosis.robotEndSpeed;
    std::cout<<std::endl<<"   "<<"The maximum acceleration:"<<robotDiagnosis.robotMaxAcc;
    std::cout<<std::endl<<"   "<<"The status bit of the software(ORPE) :"<<robotDiagnosis.orpeStatus;
    std::cout<<std::endl<<"   "<<"Enable bit of obtaining posture:"<<robotDiagnosis.enableReadPose;
    std::cout<<std::endl<<"   "<<"Mounting position status:"<<robotDiagnosis.robotMountingPoseChanged;
    std::cout<<std::endl<<"   "<<"The error status of magnetic encoder:"<<robotDiagnosis.encoderErrorStatus;
    std::cout<<std::endl<<"   "<<"The switch of static collision detection:"<<robotDiagnosis.staticCollisionDetect;
    std::cout<<std::endl<<"   "<<"Joint collision detection:"<<robotDiagnosis.jointCollisionDetect;
    std::cout<<std::endl<<"   "<<"Photo-electricity encoders(are not same)error:"<<robotDiagnosis.encoderLinesError;
    std::cout<<std::endl<<"   "<<"Joint error status:"<<robotDiagnosis.jointErrorStatus;
    std::cout<<std::endl<<"   "<<"Singularity overspeed alarm:"<<robotDiagnosis.singularityOverSpeedAlarm;
    std::cout<<std::endl<<"   "<<"Current flow error alarm:"<<robotDiagnosis.robotCurrentAlarm;
    std::cout<<std::endl<<"   "<<"tool error:"<<(int)robotDiagnosis.toolIoError;
    std::cout<<std::endl<<"   "<<"Mounting malposition:"<<robotDiagnosis.robotMountingPoseWarning;
    std::cout<<std::endl<<"   "<<"The size of mac buffer:"<<robotDiagnosis.macTargetPosBufferSize;
    std::cout<<std::endl<<"   "<<"The valid data size of mac buffer:"<<robotDiagnosis.macTargetPosDataSize;
    std::cout<<std::endl<<"   "<<"mac data interruption:"<<robotDiagnosis.macDataInterruptWarning;

    std::cout<<std::endl<<"----------------------------------end."<<std::endl;
}


void Util::initJointAngleArray(double *array, double joint0, double joint1, double joint2, double joint3, double joint4, double joint5)
{
    array[0] = joint0;
    array[1] = joint1;
    array[2] = joint2;
    array[3] = joint3;
    array[4] = joint4;
    array[5] = joint5;
}
