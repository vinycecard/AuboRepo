#ifndef EXAMPLE_ALGORITHM
#define EXAMPLE_ALGORITHM
#include "AuboRobotMetaType.h"
#include "serviceinterface.h"
class Example_algorithm
{
public:
    static void FK();
    static void IK();
    static void BaseToEnd();



};
#endif // EXAMPLE_ALGORITHM

