#ifndef EXAMPLE_EVENTPUSH
#define EXAMPLE_EVENTPUSH
#include "AuboRobotMetaType.h"
#include "serviceinterface.h"
class Example_getinfo
{
public:
    static void RealTimeWaypointCallback (const aubo_robot_namespace::wayPoint_S *wayPointPtr, void *arg);

    static void RealTimeEndSpeedCallback (double speed, void *arg);

    static void RealTimeEventInfoCallback(const aubo_robot_namespace::RobotEventInfo *pEventInfo, void *arg);


    static void eventpush();


    static void getJointStatus();

    static void getToolPara();


};
#endif // EXAMPLE_EVENTPUSH

