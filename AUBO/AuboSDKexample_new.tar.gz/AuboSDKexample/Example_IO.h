#ifndef EXAMPLE_IO
#define EXAMPLE_IO
#include "AuboRobotMetaType.h"
#include "serviceinterface.h"
class Example_IO
{
public:
   static void BoardIO();
   static void ToolIO();


};
#endif // EXAMPLE_IO

