#include "Example_init.h"
#include <stdio.h>
#include <sstream>
#include <fstream>
#include <string.h>
#include <unistd.h>

//#define SERVER_HOST "192.168.1.102"
#define SERVER_HOST "127.0.0.1"
#define SERVER_PORT 8899

void Example_init::initialization(){

    ServiceInterface robotService;

    /** interface call: login **/
    int ret = robotService.robotServiceLogin(SERVER_HOST, SERVER_PORT, "aubo", "123456");
    if(ret == aubo_robot_namespace::InterfaceCallSuccCode)
    {
        std::cerr<<"login successfully."<<std::endl;
    }
    else
    {
        std::cerr<<"login fail."<<std::endl;
    }

    /** initialize real robot **/

    aubo_robot_namespace::ROBOT_SERVICE_STATE result;

    //tool dynamics parameter
    aubo_robot_namespace::ToolDynamicsParam toolDynamicsParam;
    memset(&toolDynamicsParam, 0, sizeof(toolDynamicsParam));

    ret = robotService.rootServiceRobotStartup(toolDynamicsParam/**tool dynamics parameter**/,
                                               6        /*collisionClass*/,
                                               true     /*readPose*/,
                                               true,    /*staticCollisionDetect */
                                               1000,    /* */
                                               result); /*service state*/
    if(ret == aubo_robot_namespace::InterfaceCallSuccCode)
    {
        std::cerr<<"Initialize successfull"<<std::endl;
    }
    else
    {
        std::cerr<<"Initialize fail"<<std::endl;
    }

    /** wait for a while **/
    sleep(10);

    /** Shutdown down manipulator **/

    robotService.robotServiceRobotShutdown();

    /** logou the server**/
    robotService.robotServiceLogout();
}


