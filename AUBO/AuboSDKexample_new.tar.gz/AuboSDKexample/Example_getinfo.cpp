#include "Example_getinfo.h"
#include <stdio.h>
#include <sstream>
#include <fstream>
#include <string.h>
#include <unistd.h>
#include <math.h>
#include "util.h"
#define SERVER_HOST "127.0.0.1"
#define SERVER_PORT 8899


void Example_getinfo::RealTimeWaypointCallback(const aubo_robot_namespace::wayPoint_S *wayPointPtr, void *arg)
{
    (void)arg;
    aubo_robot_namespace::wayPoint_S waypoint = *wayPointPtr;
    Util::printWaypoint(waypoint);
}

void Example_getinfo::RealTimeEndSpeedCallback(double speed, void *arg)
{
    (void)arg;
    std::cout<<"real time end speed:"<<speed<<std::endl;
}

void Example_getinfo::RealTimeEventInfoCallback(const aubo_robot_namespace::RobotEventInfo *pEventInfo, void *arg)
{
    (void)arg;
    Util::printEventInfo(*pEventInfo);
}

void Example_getinfo::eventpush()
{
    ServiceInterface robotService;

    /** interface call: login **/
    int ret = robotService.robotServiceLogin(SERVER_HOST, SERVER_PORT, "aubo", "123456");
    if(ret == aubo_robot_namespace::InterfaceCallSuccCode)
    {
        std::cerr<<"login successfully."<<std::endl;
    }
    else
    {
        std::cerr<<"login fail."<<std::endl;
    }

    /** initialize real robot **/

    aubo_robot_namespace::ROBOT_SERVICE_STATE result;

    //tool dynamics parameter
    aubo_robot_namespace::ToolDynamicsParam toolDynamicsParam;
    memset(&toolDynamicsParam, 0, sizeof(toolDynamicsParam));

    ret = robotService.rootServiceRobotStartup(toolDynamicsParam/**tool dynamics parameter**/,
                                               6        /*collisionClass*/,
                                               true     /*readPose*/,
                                               true,    /*staticCollisionDetect */
                                               1000,    /* */
                                               result); /*service state*/
    if(ret == aubo_robot_namespace::InterfaceCallSuccCode)
    {
        std::cerr<<"Initialize successfull"<<std::endl;
    }
    else
    {
        std::cerr<<"Initialize fail"<<std::endl;
    }


    robotService.robotServiceRegisterRealTimeRoadPointCallback(Example_getinfo::RealTimeWaypointCallback, NULL);

    robotService.robotServiceRegisterRealTimeEndSpeedCallback(Example_getinfo::RealTimeEndSpeedCallback, NULL);

    robotService.robotServiceRegisterRobotEventInfoCallback(Example_getinfo::RealTimeEventInfoCallback, NULL);


    sleep(100);


    /** Shutdown down manipulator **/
    robotService.robotServiceRobotShutdown();

    /** logou the server**/
    robotService.robotServiceLogout();
}
void Example_getinfo::getJointStatus()
{
    ServiceInterface robotService;


    /** interface call: login **/
    int ret = robotService.robotServiceLogin(SERVER_HOST, SERVER_PORT, "aubo", "123456");
    if(ret == aubo_robot_namespace::InterfaceCallSuccCode)
    {
        std::cerr<<"login successfully."<<std::endl;
    }
    else
    {
        std::cerr<<"login fail."<<std::endl;
    }

    /** initialize real robot **/

    aubo_robot_namespace::ROBOT_SERVICE_STATE result;

    //tool dynamics parameter
    aubo_robot_namespace::ToolDynamicsParam toolDynamicsParam;
    memset(&toolDynamicsParam, 0, sizeof(toolDynamicsParam));

    ret = robotService.rootServiceRobotStartup(toolDynamicsParam/**tool dynamics parameter**/,
                                               6        /*collisionClass*/,
                                               true     /*readPose*/,
                                               true,    /*staticCollisionDetect */
                                               1000,    /* */
                                               result); /*service state*/
    if(ret == aubo_robot_namespace::InterfaceCallSuccCode)
    {
        std::cerr<<"Initialize successfull"<<std::endl;
    }
    else
    {
        std::cerr<<"Initialize fail"<<std::endl;
    }
    /** interface call: obtaining whether the robot is existent **/
    bool IsRealRobotExist = false;
    ret = robotService.robotServiceGetIsRealRobotExist(IsRealRobotExist);

    if(ret == aubo_robot_namespace::InterfaceCallSuccCode)
    {
        (IsRealRobotExist)? std::cout<<"existent."<<std::endl:std::cout<<"nonexistent."<<std::endl;
        std::cout<<std::endl;
    }
    else
    {
        std::cerr<<"ERROR:Fail to obtain whether the real robot is existent."<<std::endl;
    }


    /** interface: Get the joint status **/
    aubo_robot_namespace::JointStatus jointStatus[6];
    ret = robotService.robotServiceGetRobotJointStatus(jointStatus, 6);
    if(ret == aubo_robot_namespace::InterfaceCallSuccCode)
    {
        Util::printJointStatus(jointStatus, 6);
    }
    else
    {
        std::cerr<<"ERROR: Fail to get the joint status."<<"ret:"<<ret<<std::endl;
    }

    /** interface call: robot diagnoses information **/
    aubo_robot_namespace::RobotDiagnosis robotDiagnosisInfo;
    ret = robotService.robotServiceGetRobotDiagnosisInfo(robotDiagnosisInfo);
    if(ret == aubo_robot_namespace::InterfaceCallSuccCode)
    {
       Util::printRobotDiagnosis(robotDiagnosisInfo);
    }
    else
    {
        std::cerr<<"ERROR: Fail to obtain the robot diagnoses information."<<std::endl;
    }

    sleep(10);


    /** Shutdown down manipulator **/
    robotService.robotServiceRobotShutdown();

    /** logou the server**/
    robotService.robotServiceLogout();


}

void Example_getinfo::getToolPara()
{
    ServiceInterface robotService;


    /** interface call: login **/
    int ret = robotService.robotServiceLogin(SERVER_HOST, SERVER_PORT, "aubo", "123456");
    if(ret == aubo_robot_namespace::InterfaceCallSuccCode)
    {
        std::cerr<<"login successfully."<<std::endl;
    }
    else
    {
        std::cerr<<"login fail."<<std::endl;
    }

    /** initialize real robot **/

    aubo_robot_namespace::ROBOT_SERVICE_STATE result;

    //tool dynamics parameter
    aubo_robot_namespace::ToolDynamicsParam toolDynamicsParam;
    memset(&toolDynamicsParam, 0, sizeof(toolDynamicsParam));

    ret = robotService.rootServiceRobotStartup(toolDynamicsParam/**tool dynamics parameter**/,
                                               6        /*collisionClass*/,
                                               true     /*readPose*/,
                                               true,    /*staticCollisionDetect */
                                               1000,    /* */
                                               result); /*service state*/
    if(ret == aubo_robot_namespace::InterfaceCallSuccCode)
    {
        std::cerr<<"Initialize successfull"<<std::endl;
    }
    else
    {
        std::cerr<<"Initialize fail"<<std::endl;
    }
    /** interface call: obtaining whether the robot is existent **/
    bool IsRealRobotExist = false;
    ret = robotService.robotServiceGetIsRealRobotExist(IsRealRobotExist);

    if(ret == aubo_robot_namespace::InterfaceCallSuccCode)
    {
        (IsRealRobotExist)? std::cout<<"existent."<<std::endl:std::cout<<"nonexistent."<<std::endl;
        std::cout<<std::endl;
    }
    else
    {
        std::cerr<<"ERROR:Fail to obtain whether the real robot is existent."<<std::endl;
    }


    /** interface: Get the tool dynamics parameters **/
    robotService.robotServiceGetToolDynamicsParam(toolDynamicsParam);

    std::cerr<<"payload:"<<toolDynamicsParam.payload<<std::endl;
    std::cerr<<"positionX:"<<toolDynamicsParam.positionX<<std::endl;
    std::cerr<<"positionY:"<<toolDynamicsParam.positionY<<std::endl;
    std::cerr<<"positionZ:"<<toolDynamicsParam.positionZ<<std::endl;
    std::cerr<<"toolInertia.xx:"<<toolDynamicsParam.toolInertia.xx<<std::endl;



    /** interface: Get the tool kinematics parameters **/
    robotService.robotServiceSetNoneToolKinematicsParam();

    aubo_robot_namespace::ToolInEndDesc toolDesc;
    toolDesc.toolInEndPosition.x = 0;
    toolDesc.toolInEndPosition.y = 1;
    toolDesc.toolInEndPosition.z = 0;

    robotService.robotServiceGetToolKinematicsParam(toolDesc);

    std::cout<<"position information: ";
    std::cout<<"x:"<<toolDesc.toolInEndPosition.x<<"  ";
    std::cout<<"y:"<<toolDesc.toolInEndPosition.y<<"  ";
    std::cout<<"z:"<<toolDesc.toolInEndPosition.z<<std::endl;

    std::cout<<"orientation information";
    std::cout<<"w:"<<toolDesc.toolInEndOrientation.w<<"  ";
    std::cout<<"x:"<<toolDesc.toolInEndOrientation.x<<"  ";
    std::cout<<"y:"<<toolDesc.toolInEndOrientation.y<<"  ";
    std::cout<<"z:"<<toolDesc.toolInEndOrientation.z<<std::endl;

    /** interface call: robot diagnoses information **/
    aubo_robot_namespace::RobotDiagnosis robotDiagnosisInfo;
    ret = robotService.robotServiceGetRobotDiagnosisInfo(robotDiagnosisInfo);
    if(ret == aubo_robot_namespace::InterfaceCallSuccCode)
    {
       Util::printRobotDiagnosis(robotDiagnosisInfo);
    }
    else
    {
        std::cerr<<"ERROR: Fail to obtain the robot diagnoses information."<<std::endl;
    }

    sleep(10);


    /** Shutdown down manipulator **/
    robotService.robotServiceRobotShutdown();

    /** logou the server**/
    robotService.robotServiceLogout();


}
