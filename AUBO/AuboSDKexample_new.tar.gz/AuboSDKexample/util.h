#ifndef UTIL
#define UTIL
#include "AuboRobotMetaType.h"
#include "serviceinterface.h"

class Util
{
public:
    Util();
    /** print waypoint information **/
    static void printWaypoint(aubo_robot_namespace::wayPoint_S &wayPoint);

    /** print joint status information **/
    static void printJointStatus(const aubo_robot_namespace::JointStatus *jointStatus, int len);

    /** print event information **/
    static void printEventInfo(const aubo_robot_namespace::RobotEventInfo &eventInfo);

    /** print diagnoses information **/
    static void printRobotDiagnosis(const aubo_robot_namespace::RobotDiagnosis &robotDiagnosis);



    static void initJointAngleArray(double *array, double joint0,double joint1,double joint2,double joint3,double joint4,double joint5);
};

#endif // UTIL

