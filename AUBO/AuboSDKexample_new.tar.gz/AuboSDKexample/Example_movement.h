#ifndef EXAMPLE_MOVEMENT
#define EXAMPLE_MOVEMENT
#include "AuboRobotMetaType.h"
#include "serviceinterface.h"
class Example_movement
{
public:
   static void JointMove();
   static void LinearMove();
   static void TrackMove();
   static void RotaryMove();
   static void ArriveAhead();



};
#endif // EXAMPLE_MOVEMENT

