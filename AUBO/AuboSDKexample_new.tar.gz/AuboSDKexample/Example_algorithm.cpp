#include "Example_algorithm.h"
#include "util.h"
#include <stdio.h>
#include <sstream>
#include <fstream>
#include <string.h>
#include <unistd.h>
#include <math.h>

#define SERVER_HOST "127.0.0.1"
#define SERVER_PORT 8899
void Example_algorithm::FK()
{
    ServiceInterface robotService;

    aubo_robot_namespace::wayPoint_S wayPoint;

    int ret = aubo_robot_namespace::InterfaceCallSuccCode;

    double jointAngle[aubo_robot_namespace::ARM_DOF] = {0};

    Util::initJointAngleArray(jointAngle, 0.0/180.0*M_PI,  0.0/180.0*M_PI,  90.0/180.0*M_PI, 0.0/180.0*M_PI, 90.0/180.0*M_PI,   0.0/180.0*M_PI);

    ret = robotService.robotServiceRobotFk(jointAngle, aubo_robot_namespace::ARM_DOF, wayPoint);

    if(ret == aubo_robot_namespace::InterfaceCallSuccCode)
    {
        Util::printWaypoint(wayPoint);
    }
    else
    {
        std::cerr<<"forward kinematics error"<<std::endl;
    }

}

void Example_algorithm::IK()
{
    ServiceInterface robotService;

    aubo_robot_namespace::wayPoint_S wayPoint;

    int ret = aubo_robot_namespace::InterfaceCallSuccCode;

    double startPointJointAngle[aubo_robot_namespace::ARM_DOF] = {0};

    Util::initJointAngleArray(startPointJointAngle, 0.0/180.0*M_PI,  0.0/180.0*M_PI,  0.0/180.0*M_PI, 0.0/180.0*M_PI, 0.0/180.0*M_PI,0.0/180.0*M_PI);

    aubo_robot_namespace::Pos targetPosition;
    targetPosition.x =-0.400;
    targetPosition.y =-0.1215;
    targetPosition.z = 0.5476;

    aubo_robot_namespace::Rpy rpy;
    aubo_robot_namespace::Ori targetOri;

    rpy.rx = 180.0/180.0*M_PI;
    rpy.ry = 0.0/180.0*M_PI;
    rpy.rz = -90.0/180.0*M_PI;

    robotService.RPYToQuaternion(rpy, targetOri);

    ret = robotService.robotServiceRobotIk(startPointJointAngle, targetPosition, targetOri, wayPoint);

    if(ret == aubo_robot_namespace::InterfaceCallSuccCode)
    {
        Util::printWaypoint(wayPoint);
    }
    else
    {
        std::cerr<<"inverse kinematics error"<<std::endl;
    }
}
void Example_algorithm::BaseToEnd(){
    ServiceInterface robotService;
    int ret = aubo_robot_namespace::InterfaceCallSuccCode;

    /** interface call: login ***/
    ret = robotService.robotServiceLogin(SERVER_HOST, SERVER_PORT, "aubo", "123456");
    if(ret == aubo_robot_namespace::InterfaceCallSuccCode)
    {
        std::cerr<<"login successfully."<<std::endl;
    }
    else
    {
        std::cerr<<"login unsuccessfully."<<std::endl;
    }

    /** Set the coordinate parameters **/
    aubo_robot_namespace::CoordCalibrateByJointAngleAndTool userCoord;
    userCoord.coordType = aubo_robot_namespace::EndCoordinate;
    /** Set the tool parameters **/
    aubo_robot_namespace::ToolInEndDesc toolDesc;
    toolDesc.toolInEndPosition.x = 0;
    toolDesc.toolInEndPosition.y = 1;
    toolDesc.toolInEndPosition.z = 0;
    aubo_robot_namespace::wayPoint_S currentWaypoint;
    ret = robotService.robotServiceGetCurrentWaypointInfo(currentWaypoint);
     Util::printWaypoint(currentWaypoint);
    aubo_robot_namespace::Pos flangeCenterPositionOnBase;
    aubo_robot_namespace::Ori flangeCenterOrientationOnBase;
    flangeCenterPositionOnBase=currentWaypoint.cartPos.position;
    flangeCenterOrientationOnBase=currentWaypoint.orientation;
    aubo_robot_namespace::Pos toolEndPositionOnUserCoord;
    aubo_robot_namespace::Ori toolEndOrientationOnUserCoord;

    robotService.baseToUserCoordinate( flangeCenterPositionOnBase,
                                  flangeCenterOrientationOnBase,
                                   userCoord,
                                  toolDesc,
                                 toolEndPositionOnUserCoord,
                                  toolEndOrientationOnUserCoord
                                  );
//position
std::cout<<"position information: ";
std::cout<<"x:"<<toolEndPositionOnUserCoord.x<<"  ";
std::cout<<"y:"<<toolEndPositionOnUserCoord.y<<"  ";
std::cout<<"z:"<<toolEndPositionOnUserCoord.z<<std::endl;
//quaternion
std::cout<<"posture information described by quaternion: ";
std::cout<<"w:"<<toolEndOrientationOnUserCoord.w<<"  ";
std::cout<<"x:"<<toolEndOrientationOnUserCoord.x<<"  ";
std::cout<<"y:"<<toolEndOrientationOnUserCoord.y<<"  ";
std::cout<<"z:"<<toolEndOrientationOnUserCoord.z<<std::endl;


}
